var main_menu = document.getElementById("main_menu");
var menu = document.getElementById("menu_container");
var main_menu_visible = false;
var menu_links = menu.getElementsByClassName("menu__link");
//Рисуем треугольники, т.к. affter и before не доступны в js
var triangle1 = document.createElement("div");
triangle1.classList.add('triangle_in_menu');
main_menu.append(triangle1);
var triangle2 = document.createElement("div");
triangle2.classList.add('triangle_in_menu');
triangle2.classList.add('triangle_in_menu_2');
main_menu.append(triangle2);


function show_main_menu() {
    main_menu.style.display = "flex";
    if (this.id != "main_menu") {
        let offset = (this.getBoundingClientRect().left + this.getBoundingClientRect().right) / 2 - main_menu.getBoundingClientRect().left - 6;
        triangle1.style.left = offset.toFixed(0) + "px";
        triangle2.style.left = offset.toFixed(0) + "px";
    }
    main_menu_visible = true;
}


function hide_main_menu() {
    main_menu.style.display = "none";
    main_menu_visible = false;
}


function my_click() {
    if (main_menu_visible) {
        hide_main_menu();
    } else show_main_menu();

}


window.onload = function () {

    main_menu.onmouseover = show_main_menu;

    for (let i = 0; i < menu_links.length; i += 1) {
        el = menu_links[i];
        if (!el.classList.contains("menu__link__href")) {
            el.onmouseover = show_main_menu;
            el.onmouseout = hide_main_menu;
            el.onclick = my_click;
        }
    }

}
